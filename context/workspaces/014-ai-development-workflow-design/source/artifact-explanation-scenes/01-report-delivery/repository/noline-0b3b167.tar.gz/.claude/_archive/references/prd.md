# Noline - 프로젝트 기획서 (Product Requirements Document)

## 📌 프로젝트 개요

**프로젝트명**: Noline (No + Offline)  
**플랫폼**: React Native (iOS / Android)  
**버전**: 1.0.0  
**아키텍처**: Local-First 오프라인 우선 설계

Noline은 여행 중 불안정한 네트워크 환경에서도 완벽하게 작동하는 여행 관리 모바일 앱입니다. **단순 오프라인 저장을 넘어, 여행 기간 동안의 '오프라인 활성화' 개념**을 도입하여 사용자에게 "한번 받으면 끝"이 아니라 "여행 내내 최신 상태로 알아서 관리해준다"는 신뢰와 가치를 제공합니다.

---

## 🎯 해결하고자 하는 문제

### 핵심 문제

1. **불안정한 네트워크 환경에서의 데이터 손실**
   - 해외 여행 중 로밍 비용 부담으로 데이터를 아껴 사용
   - WiFi가 없는 관광지, 교통수단 내에서 앱 사용 불가
   - **네트워크 끊김 중 입력한 데이터가 사라지는 문제**
   - 서버 응답을 기다리는 동안 발생하는 답답한 로딩 시간

2. **복잡한 여행 관리**
   - 일정, 경비, 지도를 각각 다른 앱에서 관리
   - 영수증 사진과 금액을 수기로 기록하는 번거로움
   - 여행 후 정산 시 누락된 지출 내역 발생

3. **실시간 정보 접근의 어려움**
   - 다음 일정 확인을 위해 매번 인터넷 연결 필요
   - 지도 앱이 오프라인에서 작동하지 않음
   - 환율 정보, 경비 현황을 즉시 확인 불가

### 타겟 사용자

**주 타겟**

- 해외 배낭여행을 즐기는 20-30대
- 예산 관리를 중요하게 생각하는 여행자
- 로밍 데이터 사용을 최소화하고 싶은 사람

**부 타겟**

- 출장이 잦은 비즈니스 여행자
- 가족 여행 경비를 관리하는 부모
- 장기 여행자 (디지털 노마드, 워홀러)

---

## 💎 핵심 가치 제안

### "네트워크가 없어도 여행은 계속된다"

#### 1. **Selective Activation 기반 Local-First 경험**

> ⚠️ **v2.0 정책 업데이트** (2025-11): 아래 내용은 초기 설계안입니다.
> 현재 구현된 아키텍처는 [selective-activation-architecture.md](../../context/selective-activation-architecture.md)를 참조하세요.

- **활성화된 여행**: 로컬 SQLite가 진실의 원천 → 오프라인 완전 지원
- **비활성 여행**: 서버 API가 진실의 원천 → 온라인 전용, 저장공간 절약
- 네트워크 상태와 무관하게 활성화된 여행은 즉각적인 반응성 보장
- 데이터 손실 0%: 활성화된 여행의 변경사항은 로컬에 저장 후 백그라운드 동기화

#### 2. **오프라인 활성화 시스템**

- 단순 "다운로드"가 아닌 **"여행 활성화"** 개념
- 여행 기간 동안 자동으로 최신 데이터 Pull
- 사용자에게 "한번 설정하면 여행 내내 알아서 관리해준다"는 신뢰 제공
- 활성화하지 않은 여행: 최대 10개의 sync_queue만 허용, 초과 시 활성화 유도

#### 3. **견고한 동기화 메커니즘**

- **Outbox Pattern**: 데이터 변경과 sync_queue 기록을 원자적 트랜잭션으로 묶음
- **Axios Interceptor**: 네트워크 불안정 시 자동 재시도 (Exponential Backoff)
- **Last-Write-Wins**: 초기 버전의 단순하고 안정적인 충돌 해결
- **Version 필드**: 향후 정교한 충돌 해결 로직으로 업그레이드 가능한 기반

#### 4. **똑똑한 경비 관리**

- 영수증 사진 촬영 시 OCR로 자동 금액 인식 (향후)
- 일정별, 날짜별 경비 자동 분류
- 오프라인에서도 실시간 총 경비 현황 확인

---

## 🏗️ 아키텍처 핵심 원칙

### Selective Activation 아키텍처

> ⚠️ 아래 다이어그램은 초기 설계안입니다. 현재 구현된 아키텍처는 Activation Router를 통해 활성화 상태에 따라 자동 분기합니다.

```text
┌─────────────────────────────────────────────────────────┐
│                   UI Layer (React Native)               │
│              (React Query를 통해 데이터 조회)              │
└────────────────────┬────────────────────────────────────┘
                     │
                     ↓
┌─────────────────────────────────────────────────────────┐
│              Activation Router (v2.0)                    │
│    routeTripQuery/Mutation, routeChildQuery/Mutation    │
└────────────────────┬────────────────────────────────────┘
                     │
         ┌───────────┴───────────┐
         ↓                       ↓
   [활성화된 여행]          [비활성 여행]
         ↓                       ↓
   Local SQLite            Remote Server
         ↓
   sync_queue (Outbox)
         ↓
   Background Sync → Server
```

### 핵심 정책

1. **클라이언트 ULID 생성**: 모든 데이터 ID는 클라이언트에서 ULID로 생성 → 오프라인 충돌 방지
2. **Outbox Pattern**: 데이터 변경 + sync_queue 기록을 하나의 트랜잭션으로 묶어 데이터 손실 방지
3. **React Query 진입점**: 모든 데이터 작업은 React Query를 통해 → 낙관적 업데이트, 에러 처리, 일관된 패턴
4. **활성화 기반 동기화**: 여행 기간 동안 자동으로 서버에서 최신 데이터 Pull

---

## 🎨 주요 기능

### 1️⃣ 여행 관리 (Trips)

**기능**

- 여행지, 국가, 날짜 설정
- **여행 활성화**: 여행 생성 시 자동으로 활성화 설정
- 여행별 일정/경비 그룹화
- 여행 목록 조회 (오프라인 가능)

**사용 시나리오**

> 유저가 "파리, 프랑스 2025-10-20 ~ 2025-10-27" 여행을 생성하면, 클라이언트에서 ULID를 생성하고 즉시 로컬 DB에 저장됩니다. 동시에 sync_queue에 PENDING 작업이 기록되며, 온라인 상태가 되면 백그라운드로 서버에 Push됩니다. 이후 여행 기간 동안 서버의 최신 데이터가 자동으로 Pull됩니다.

---

### 2️⃣ 일정 관리 (Schedules)

**기능**

- 날짜별 일정 생성 (제목, 시간, 장소)
- 위도/경도 기반 위치 정보 저장
- 지도 뷰 / 리스트 뷰 전환
- 일정 순서 자동 정렬 (시간 순)
- **오프라인 일정 추가**: 네트워크 없이도 즉시 UI에 반영

**사용 시나리오**

> 지하철 안에서 "09:00 에펠탑 방문" 일정을 추가하면, 오프라인 상태임에도 즉시 화면에 표시됩니다. 로컬 DB에 저장되고 sync_queue에 기록된 후, WiFi에 연결되면 자동으로 서버와 동기화됩니다.

**지도 기능**

- 일정 위치를 지도에 마커로 표시
- 마커 클릭 시 일정 상세 확인
- 오프라인 지도 타일 캐싱 (향후)

---

### 3️⃣ 경비 관리 (Expenses)

**기능**

- 경비 기록 (금액, 카테고리, 메모)
- 일정에 연결된 경비 자동 분류
- 날짜별 경비 그룹화 및 합계
- **오프라인 경비 추가**: 영수증을 받는 즉시 기록 가능
- OCR 영수증 스캔 (향후)

**카테고리**

- 🍽️ 식비
- 🚌 교통
- 🏨 숙박
- 🎫 관광
- 🛍️ 쇼핑
- 💊 의료
- 📱 통신
- 🎉 기타

**사용 시나리오**

> 레스토랑에서 식사 후 WiFi가 없는 상황에서도 "🍽️ 점심 EUR 15.80"을 즉시 입력합니다. 데이터는 로컬 DB에 저장되고 총 경비에 즉시 반영됩니다. 호텔로 돌아와 WiFi에 연결되면 자동으로 서버와 동기화됩니다.

---

### 4️⃣ 오프라인 활성화 & 동기화 시스템

#### **데이터 조회 (Read)**

1. UI는 React Query 훅을 통해 데이터 요청
2. React Query의 `queryFn`은 **항상 로컬 DB(SQLite)** 조회
3. 로컬 DB에 데이터가 없으면 빈 상태 렌더링
4. Sync Engine이 백그라운드에서 서버 데이터를 Pull하여 로컬 DB 채움

#### **데이터 수정 (Create, Update, Delete)**

1. UI에서 데이터 변경 요청 → `useMutation` 실행
2. 서비스 계층에서 **원자적 트랜잭션** 실행:
   - a. ULID 생성
   - b. Zod 스키마 검증
   - c. 데이터 테이블(예: expenses)에 저장
   - d. sync_queue에 PENDING 작업 기록
3. **낙관적 업데이트**: React Query가 즉시 UI 갱신
4. **백그라운드 Push**: 온라인 시 Sync Engine이 서버로 전송

#### **Pull 동기화**

1. Sync Engine이 주기적 또는 네트워크 복구 시 서버로 Pull 요청
2. `last_synced_at` 이후 변경된 데이터를 서버에서 조회
3. 로컬 DB에 Upsert (Update or Insert)
4. React Query 캐시 무효화 → UI 자동 갱신

#### **활성화 시스템**

- **활성화한 여행**: 여행 기간 동안 자동 Pull, 무제한 sync_queue
- **미활성 여행**: 최대 10개 sync_queue, 초과 시 활성화 유도 메시지

#### **네트워크 상태 표시**

- 🟢 **온라인**: 실시간 동기화 활성
- 🟡 **불안정**: Axios Interceptor가 재시도 중
- 🔴 **오프라인**: 로컬 저장만 가능, sync_queue 대기 중

---

## 🗺️ 화면 구성

### 1. 홈 (Trips)

- 여행 목록 카드 리스트
- FAB 버튼으로 새 여행 추가
- 여행별 일정 개수, 총 경비 미리보기
- **활성화 상태 표시**: 활성화 중 / 미활성

### 2. 일정 (Schedules)

- 헤더: 제목 + 지도/리스트 전환 버튼
- 여행 선택 (Sticky)
- 날짜별 일정 카드 리스트
- 지도 뷰: 일정 위치 마커 표시
- **오프라인 인디케이터**: sync_queue 대기 중 표시

### 3. 경비 (Expenses)

- 헤더: 제목
- 여행 선택 (Sticky)
- 총 경비 요약 카드 (로컬 DB 기반 실시간 계산)
- 날짜별 경비 카드 리스트
- 카테고리별 아이콘 표시
- **동기화 상태**: 각 항목의 sync 여부 표시

### 4. 프로필 (Profile)

- 사용자 정보
- 설정 (언어, 통화, 테마)
- **수동 동기화 버튼**: Pull-to-Refresh
- **동기화 상태 표시줄**: PENDING 작업 개수

---

## 🛠️ 기술 스택

### Frontend (React Native)

- **React Native** + **TypeScript**: 네이티브 모바일 앱
- **Expo**: 빠른 개발 및 배포
- **React Navigation**: 네이티브 네비게이션
- **React Query (TanStack Query)**: 로컬 DB 상태 관리 및 캐싱
- **NativeWind**: Tailwind CSS for React Native
- **Drizzle ORM**: SQLite 타입 안전 쿼리

### Local Database

- **SQLite**: 오프라인 로컬 DB
- **expo-sqlite**: React Native SQLite 드라이버
- **Drizzle ORM**: 타입 안전 스키마 및 쿼리

### Synchronization

- **Axios**: 동기화 엔진의 서버 통신
- **Axios Interceptor**: 자동 재시도 로직 (Exponential Backoff)
- **ULID**: 클라이언트 고유 ID 생성
- **Zod**: 데이터 스키마 검증

### Backend

- **Express.js**: RESTful API 서버
- **PostgreSQL** (Neon): 서버리스 데이터베이스
- **Drizzle ORM**: 서버 DB 타입 안전 쿼리

### Shared (Monorepo)

- **packages/schema**: Zod 스키마 (클라이언트 ↔ 서버 공유)

---

## 🗄️ 데이터 스키마

### 공통 필드 (모든 핵심 테이블)

- **`id`** (TEXT, Primary Key): 클라이언트 생성 **ULID**
- **`updated_at`** (TIMESTAMP): 마지막 수정 시간 (Pull 동기화 기준)
- **`deleted_at`** (TIMESTAMP, Nullable): 소프트 삭제 시간
- **`version`** (INTEGER, Default 1): 충돌 해결 고도화를 위한 버전 필드

### `sync_queue` 테이블

| 필드명         | 타입        | 설명                                           |
| -------------- | ----------- | ---------------------------------------------- |
| `id`           | TEXT (ULID) | 작업 고유 ID                                   |
| `table_name`   | TEXT        | 변경된 테이블 이름 (예: 'expenses')            |
| `record_id`    | TEXT        | 변경된 레코드의 ID                             |
| `action`       | TEXT        | 작업 종류 ('CREATE', 'UPDATE', 'DELETE')       |
| `payload`      | TEXT (JSON) | 서버로 보낼 데이터 본문                        |
| `status`       | TEXT        | 작업 상태 ('PENDING', 'IN_PROGRESS', 'FAILED') |
| `retry_count`  | INTEGER     | 실패 시 재시도 횟수                            |
| `created_at`   | TIMESTAMP   | 작업 생성 시간                                 |
| `dependencies` | TEXT (JSON) | (Phase 2) 선행 작업 ID 목록                    |

### 예시: `expenses` 테이블

```sql
CREATE TABLE expenses (
    -- 공통 필드 --
    id TEXT PRIMARY KEY,           -- 클라이언트 생성 ULID
    updated_at TIMESTAMP NOT NULL, -- 마지막 수정 시간
    deleted_at TIMESTAMP,          -- 소프트 삭제 (NULL = 활성)
    version INTEGER DEFAULT 1,     -- 충돌 해결용 버전

    -- 비즈니스 필드 --
    trip_id TEXT NOT NULL,         -- 여행 ID (FK)
    schedule_id TEXT,              -- 일정 ID (FK, Nullable)
    title TEXT NOT NULL,           -- 경비 항목명
    amount REAL NOT NULL,          -- 금액
    currency TEXT NOT NULL,        -- 통화 (EUR, USD 등)
    category TEXT NOT NULL,        -- 카테고리 (식비, 교통 등)
    spent_at TIMESTAMP NOT NULL,   -- 지출 발생 시간
    memo TEXT                      -- 메모
);
```

---

## 📅 개발 로드맵 (포트폴리오 학습 경로)

### ✅ Phase 1: 기반 구축과 '행복한 길' (완료 - 웹 프로토타입)

**🎯 목표:** 로컬 DB 기반 앱 핵심 골격 완성 (v1.0 Pure Local-First)

**주요 작업:**

- [x] 여행 CRUD
- [x] 일정 CRUD
- [x] 경비 CRUD
- [x] 날짜별 그룹화
- [x] 여행별 필터링
- [x] 기본 UI/UX

**💡 이 단계에서 배운 것:**

- ✨ **트랜잭션의 중요성**: `expenses` 저장 + `sync_queue` 기록을 묶지 않으면 데이터 정합성이 깨짐 (UI에는 보이는데 동기화 목록에는 없는 상황)
- ✨ **React Query 캐시 관리**: 어떤 `queryKey`를 무효화해야 UI가 효율적으로 갱신되는지 학습
- ✨ **sync_queue 쌓임 관찰**: 데이터는 계속 쌓이지만 처리되지 않음 → 동기화 엔진의 필요성 체감

---

### 🚧 Phase 2: 동기화 엔진과 '불행한 길' (현재)

**🎯 목표:** 실제 서버 통신 및 네트워크 예외 상황 처리

**주요 작업:**

- [ ] **스키마 확장**: `id` → ULID, `version`, `deleted_at` 필드 추가
- [ ] **SQLite + Drizzle ORM**: 로컬 DB 레이어 구축
- [ ] **sync_queue 구현**: Outbox Pattern 적용
- [ ] **Sync Engine v1**: Push/Pull 기본 로직
- [ ] **Axios Interceptor**: 자동 재시도 로직 (Exponential Backoff)
- [ ] **수동 동기화**: UI 버튼 + 앱 시작 시 1회 실행

**💡 예상 학습 포인트:**

- ⚠️ **낙관적 업데이트의 배신**: 서버 동기화 실패 시 UI는 성공한 것처럼 보임 → 사용자 피드백과 롤백 로직 필요성
- ⚠️ **FIFO 순서 보장**: 오프라인에서 "여행 생성 → 경비 생성" 순서가 깨지면 서버 에러 발생 → **순차 처리 필수**
- ⚠️ **수동 동기화의 불편함**: 사용자가 매번 버튼 클릭? → Phase 3 자동화 필요

---

### 🔄 Phase 3: 고도화 및 실제 사용 환경

**🎯 목표:** 동기화 자동화, 성능 최적화, 프로덕션 수준 완성도

**주요 작업:**

- [ ] **자동 동기화 트리거**:
  - NetInfo: 네트워크 온라인 시 자동 실행
  - AppState: 포어그라운드 복귀 시 자동 실행
  - 주기적 동기화 (5분마다)
- [ ] **네트워크 상태 감지**: `useNetworkStatus` 훅 (Heartbeat 기반)
- [ ] **고급 에러 핸들링**:
  - 비즈니스 로직 에러 처리 (예: 예산 초과)
  - 영구 FAILED 상태 관리
  - 사용자 알림 및 수정 유도 UI
- [ ] **성능 최적화**:
  - 초기 대량 데이터 로딩 (페이지네이션 + 청크 저장)
  - Push 요청 Batching (여러 작업 묶어서 전송)
- [ ] **SyncProvider**: 앱 전역 동기화 관리
- [ ] **활성화 시스템**: 여행 활성화 로직
- [ ] **UI/UX 피드백**: 동기화 상태 스낵바, Pull-to-Refresh

**💡 예상 학습 포인트:**

- ⚠️ **백그라운드 동기화의 어려움**: React Native 환경의 제약, 네이티브 기능 필요성 이해
- ⚠️ **상태 복잡도 폭발**: 데이터 상태 + 캐시 상태 + 동기화 상태 + 네트워크 상태 → 전역 상태 관리(Zustand) 필요
- ⚠️ **테스트 전략**: 다양한 오프라인 시나리오 테스트의 어려움, Mock 전략 학습

---

### 🎯 Phase 4: React Native 마이그레이션

- [ ] Expo 프로젝트 설정
- [ ] React Native 컴포넌트 전환
- [ ] expo-sqlite 통합
- [ ] 네이티브 네비게이션
- [ ] 디바이스 테스트

---

### 🔮 Phase 5: 고급 기능

- [ ] OCR 영수증 스캔
- [ ] 지도 오프라인 타일 캐싱
- [ ] 실제 장소 검색 (Photon API)
- [ ] 다국어 지원 (i18n)
- [ ] 환율 자동 변환

---

### 🚀 Phase 6: 사용자 경험 개선

- [ ] 사용자 인증 (로그인/회원가입)
- [ ] 여행 공유 기능
- [ ] 통계 대시보드
- [ ] PDF 여행 리포트 생성
- [ ] 위젯 지원

---

## 🎨 디자인 테마

**Forest Green Theme** (#228B22)

- 자연, 여행, 모험을 연상시키는 포레스트 그린 컬러
- 모바일 전용 디자인 (375px 기준)
- 다크모드 지원
- Material Design 3 원칙

**핵심 원칙**

- 간결함: 불필요한 요소 제거
- 직관성: 한눈에 파악 가능한 정보 구조
- 접근성: 색맹, 저시력 사용자 고려
- **오프라인 투명성**: 동기화 상태를 명확하게 표시

---

## 📊 성공 지표 (KPI)

### 기술 지표

- **오프라인 모드에서 핵심 기능 100% 작동**
- **네트워크 복구 후 5초 이내 자동 동기화**
- **데이터 손실 0건**: sync_queue 기반 보장
- **평균 UI 반응 속도 < 100ms**: 로컬 DB 기반

### 사용성

- 평균 경비 입력 시간 30초 이하
- 일정 추가 완료율 95% 이상

### 사용자 만족도

- 앱 크래시율 1% 이하
- 평균 앱 평점 4.5+ (5점 만점)
- 오프라인 기능 만족도 90% 이상

### 비즈니스

- MAU (월간 활성 사용자) 10,000명
- 사용자 1인당 평균 여행 생성 3개
- 활성화 전환율 70% 이상

---

## 🚀 출시 계획

### 베타 테스트 (Phase 4 완료 후)

- 타겟: 여행 커뮤니티 50명
- 기간: 2주
- 목표: 오프라인 동기화 검증, 버그 수집

### 정식 출시

- 플랫폼: React Native (iOS / Android)
- 배포: App Store, Google Play
- 마케팅: 여행 커뮤니티, 배낭여행 블로거

---

## 📝 참고 문서

**현재 아키텍처 (v2.0+):**

- [selective-activation-architecture.md](../../context/selective-activation-architecture.md) - Selective Activation 상세 아키텍처
- [policy-architecture.md](../../context/policy-architecture.md) - Policy Layer 가이드 (v3.0)
- [CHANGELOG.md](../../CHANGELOG.md) - 정책 변경 히스토리

**히스토리 (아카이브):**

- [local-first-impl-v1.md](../local-first-impl-v1.md) - v1.0 Echo Architecture 구현 가이드 (아카이브)

---

## 🔍 핵심 차별점

| 기존 여행 앱                 | Noline                                  |
| ---------------------------- | --------------------------------------- |
| 온라인 필수                  | **오프라인 우선**                       |
| 서버 응답 대기               | **즉각적인 UI 반응** (로컬 DB)          |
| 네트워크 끊김 시 데이터 손실 | **데이터 손실 0%** (Outbox Pattern)     |
| 단순 캐싱                    | **활성화 기반 자동 동기화**             |
| UUID (서버 생성)             | **ULID** (클라이언트 생성, 시간순 정렬) |
| 복잡한 충돌 해결             | **Last-Write-Wins** (단순하고 안정적)   |

---

**마지막 업데이트**: 2025-10-19  
**작성자**: Noline Team

> "여행의 모든 순간을 기록하세요. 네트워크는 신경 쓰지 마세요."
