/**
 * 날짜/시간 유틸리티 함수
 *
 * 시점은 ISO datetime으로 저장·전송하고 기기 시간대로 표시한다.
 * 달력 날짜(YYYY-MM-DD)는 시점으로 변환하지 않는다.
 */

/**
 * 사용자의 현재 타임존 반환
 *
 * @returns 타임존 문자열 (예: "Asia/Seoul", "Europe/Paris")
 */
export function getUserTimezone(): string {
  return Intl.DateTimeFormat().resolvedOptions().timeZone;
}

/**
 * Date 객체를 ISO 8601 string with timezone으로 변환
 *
 * @param date - Date 객체
 * @returns ISO 8601 string (예: "2024-01-15T14:30:00.000Z")
 *
 * @example
 * ```ts
 * const date = new Date('2024-01-15T14:30:00');
 * toISOString(date);
 * // → "2024-01-15T14:30:00.000Z"
 * ```
 */
export function toISOString(date: Date): string {
  return date.toISOString();
}

/**
 * 날짜와 시간을 조합해서 ISO string으로 변환
 *
 * @param date - 날짜 ("2024-01-15" 또는 Date 객체)
 * @param time - 시간 ("14:30" 형식)
 * @returns ISO 8601 string with timezone
 *
 * @example
 * ```ts
 * combineDateTimeToISO("2024-01-15", "14:30");
 * // → "2024-01-15T05:30:00.000Z" (기기가 Asia/Seoul인 경우)
 *
 * combineDateTimeToISO(new Date(), "14:30");
 * // → 오늘 날짜 14:30의 ISO string
 * ```
 */
export function combineDateTimeToISO(date: string | Date, time: string): string {
  const dateString = typeof date === 'string' ? date : formatISOToLocalDate(date.toISOString());

  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateString) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) {
    throw new Error('날짜와 시간을 다시 선택해주세요.');
  }

  const [year, month, day] = dateString.split('-').map(Number);
  const [hours, minutes] = time.split(':').map(Number);
  // 날짜 문자열을 UTC 자정으로 읽지 않고 로컬 달력의 구성요소로 만든다.
  const dateObj = new Date(0);

  dateObj.setFullYear(year, month - 1, day);
  dateObj.setHours(hours, minutes, 0, 0);

  if (
    !Number.isFinite(dateObj.getTime()) ||
    dateObj.getFullYear() !== year ||
    dateObj.getMonth() !== month - 1 ||
    dateObj.getDate() !== day ||
    dateObj.getHours() !== hours ||
    dateObj.getMinutes() !== minutes
  ) {
    // 존재하지 않는 날짜 또는 DST 전환으로 건너뛴 시간을 자동 보정하지 않는다.
    throw new Error('현재 기기 시간대에서 사용할 수 없는 날짜·시간입니다. 다시 선택해주세요.');
  }

  return dateObj.toISOString();
}

/** 기존 Trip timestamp의 UTC 날짜 기준으로 달력 날짜를 나열한다. */
export function getUTCDateRange(startISO: string, endISO: string): string[] {
  const current = new Date(startISO);
  const end = new Date(endISO);

  if (!Number.isFinite(current.getTime()) || !Number.isFinite(end.getTime())) return [];

  current.setUTCHours(0, 0, 0, 0);
  end.setUTCHours(0, 0, 0, 0);

  const dates: string[] = [];

  while (current <= end) {
    dates.push(current.toISOString().split('T')[0]);
    current.setUTCDate(current.getUTCDate() + 1);
  }

  return dates;
}

/**
 * ISO string을 로컬 날짜 문자열로 변환
 *
 * @param isoString - ISO 8601 string
 * @param format - 날짜 형식 (기본: "YYYY-MM-DD")
 * @returns 로컬 날짜 문자열
 *
 * @example
 * ```ts
 * formatISOToLocalDate("2024-01-15T14:30:00.000Z");
 * // → "2024-01-15"
 *
 * formatISOToLocalDate("2024-01-15T14:30:00.000Z", "MM/DD/YYYY");
 * // → "01/15/2024"
 * ```
 */
export function formatISOToLocalDate(
  isoString: string,
  format: 'YYYY-MM-DD' | 'MM/DD/YYYY' | 'DD/MM/YYYY' = 'YYYY-MM-DD',
): string {
  const date = new Date(isoString);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');

  switch (format) {
    case 'MM/DD/YYYY':
      return `${month}/${day}/${year}`;
    case 'DD/MM/YYYY':
      return `${day}/${month}/${year}`;
    case 'YYYY-MM-DD':
    default:
      return `${year}-${month}-${day}`;
  }
}

/**
 * ISO string을 로컬 시간 문자열로 변환
 *
 * @param isoString - ISO 8601 string
 * @param format - 시간 형식 (기본: "HH:mm")
 * @returns 로컬 시간 문자열
 *
 * @example
 * ```ts
 * formatISOToLocalTime("2024-01-15T14:30:00.000Z");
 * // → "14:30" (사용자 타임존 기준)
 *
 * formatISOToLocalTime("2024-01-15T14:30:00.000Z", "HH:mm:ss");
 * // → "14:30:00"
 * ```
 */
export function formatISOToLocalTime(isoString: string, format: 'HH:mm' | 'HH:mm:ss' = 'HH:mm'): string {
  const date = new Date(isoString);
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');

  return format === 'HH:mm:ss' ? `${hours}:${minutes}:${seconds}` : `${hours}:${minutes}`;
}

/**
 * ISO string을 로컬 날짜+시간 문자열로 변환
 *
 * @param isoString - ISO 8601 string
 * @returns 로컬 날짜+시간 문자열
 *
 * @example
 * ```ts
 * formatISOToLocalDateTime("2024-01-15T14:30:00.000Z");
 * // → "2024-01-15 14:30"
 * ```
 */
export function formatISOToLocalDateTime(isoString: string): string {
  const date = formatISOToLocalDate(isoString);
  const time = formatISOToLocalTime(isoString);
  return `${date} ${time}`;
}

/**
 * 두 ISO string 날짜가 같은 날인지 확인
 *
 * @param isoString1 - 첫 번째 ISO string
 * @param isoString2 - 두 번째 ISO string
 * @returns 같은 날이면 true
 *
 * @example
 * ```ts
 * isSameDay(
 *   "2024-01-15T14:30:00.000Z",
 *   "2024-01-15T20:00:00.000Z"
 * );
 * // → true
 * ```
 */
export function isSameDay(isoString1: string, isoString2: string): boolean {
  const date1 = formatISOToLocalDate(isoString1);
  const date2 = formatISOToLocalDate(isoString2);
  return date1 === date2;
}

/**
 * ISO string을 상대 시간으로 변환
 *
 * @param isoString - ISO 8601 string
 * @returns 상대 시간 문자열 (예: "2 hours ago", "in 3 days")
 *
 * @example
 * ```ts
 * formatISOToRelative("2024-01-15T14:30:00.000Z");
 * // → "2 hours ago" (현재 시간 기준)
 * ```
 */
export function formatISOToRelative(isoString: string): string {
  const date = new Date(isoString);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return 'just now';
  if (diffMins < 60) return `${diffMins} minutes ago`;
  if (diffHours < 24) return `${diffHours} hours ago`;
  if (diffDays < 7) return `${diffDays} days ago`;

  return formatISOToLocalDate(isoString);
}

/**
 * 날짜 문자열을 ISO datetime string으로 변환 (UTC 자정 기준)
 *
 * @param dateString - 날짜 문자열 ("2024-03-15" 형식 또는 ISO datetime)
 * @returns ISO 8601 datetime string
 *
 * @example
 * ```ts
 * dateToISODateTime("2024-03-15");
 * // → "2024-03-15T00:00:00.000Z"
 *
 * dateToISODateTime("2024-03-15T10:30:00.000Z");
 * // → "2024-03-15T10:30:00.000Z" (이미 ISO datetime이면 그대로 반환)
 * ```
 */
export function dateToISODateTime(dateString: string): string {
  if (!dateString) {
    throw new Error('dateString is required');
  }

  // 이미 ISO datetime 형식인 경우 (T 포함)
  if (dateString.includes('T')) {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) {
      throw new Error(`Invalid datetime string: ${dateString}`);
    }
    return date.toISOString();
  }

  // "YYYY-MM-DD" 형식인 경우
  // YYYY-MM-DD 형식 검증
  const dateOnlyRegex = /^\d{4}-\d{2}-\d{2}$/;
  if (!dateOnlyRegex.test(dateString)) {
    throw new Error(`Invalid date format: ${dateString}. Expected YYYY-MM-DD or ISO datetime`);
  }

  const date = new Date(dateString + 'T00:00:00.000Z'); // UTC 자정
  if (isNaN(date.getTime())) {
    throw new Error(`Invalid date: ${dateString}`);
  }

  return date.toISOString();
}
