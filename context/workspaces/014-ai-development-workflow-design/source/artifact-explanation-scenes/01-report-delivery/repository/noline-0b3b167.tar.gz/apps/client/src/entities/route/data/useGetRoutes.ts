/**
 * useGetRoutes - 경로 조회 훅
 * - tripId로 모든 경로 조회
 * - 오프라인 지도 경로 표시용
 */

import { useQuery } from '@tanstack/react-query';
import { eq, and, isNull } from 'drizzle-orm';
import { getDatabase, routes, type Route } from '@/shared/db';
import { routeQueryKeys } from './keys';

/**
 * 여행의 모든 경로 조회 (Soft Delete 제외)
 * @param tripId - 여행 ID
 */
export function useGetRoutes({ tripId }: { tripId: string }) {
  return useQuery({
    queryKey: routeQueryKeys.byTrip(tripId),
    queryFn: async (): Promise<Route[]> => {
      console.log('[Routes] Fetching routes for trip:', tripId);

      const result = await getDatabase()
        .select()
        .from(routes)
        .where(and(eq(routes.tripId, tripId), isNull(routes.deletedAt)))
        .all();

      console.log(`[Routes] Found ${result.length} routes`);
      return result;
    },
  });
}

/**
 * 특정 Schedule 도착 경로 조회
 * @param scheduleId - 도착 Schedule ID
 */
export function useGetRouteToSchedule({ scheduleId }: { scheduleId: string }) {
  return useQuery({
    queryKey: routeQueryKeys.toSchedule(scheduleId),
    queryFn: async (): Promise<Route | undefined> => {
      const result = await getDatabase()
        .select()
        .from(routes)
        .where(and(eq(routes.toScheduleId, scheduleId), isNull(routes.deletedAt)))
        .get();

      return result;
    },
  });
}
