# 이름을 바꿀 때와 동작을 고칠 때

같은 동작을 이해시키는 표현이 여러 개일 때는 이름을 바꾸는 이득과 비용을 비교할 수 있다. 소비자가 필요한 결과 자체가 없다면 표현 비교에 앞서 동작을 고쳐야 한다. 아래 인증과 저장 예시는 그 차이를 보여 준다. 판단 기준은 [이름·책임·완료 범위](INDEX.md)에 있다.

## 같은 동작에서 이름 유지와 개명 비교

로그인을 마치면 여행 화면으로 이동하고, 재인증을 마치면 모달을 닫는 예제를 보자. 인증 서비스는 세션 적용까지 마친다. 그다음 wrapper가 여행 데이터 조회를 요청하지만 조회 결과를 기다리지는 않는다. 두 소비자는 최신 조회 값을 즉시 읽지 않으므로 이 시점에 이동·닫기를 시작할 수 있다.

이것은 실행 가능한 인증 demo의 동작을 바탕으로 만든 표현 비교다. 실제 제품의 변경 전후를 복원한 사례는 아니다. 내부 소비자는 Login과 Reauth 두 곳이며 공개 호환 계약은 없다고 놓았다. 완료·오류 callback은 정상 반환한다. 실제 화면·네트워크의 완료를 검증한 예시도 아니다.

### 두 안이 공통으로 제공하는 결과

| 경계 | 완료 callback과 성공 반환 시 알 수 있는 것 |
| --- | --- |
| 인증 | 인증 서비스가 세션 적용을 마쳤고 같은 session을 돌려받는다. |
| 조회 | 요청을 시도했으나 최신 조회 결과가 준비됐다고 보장하지 않는다. 요청 중 발생한 동기 오류와 후속 실패는 `onRefreshError`로 따로 전달한다. |
| 소비자 | 이동이나 모달 닫기를 시작할 수 있다. wrapper는 화면 준비 완료를 관찰하지 않는다. |

다음은 A의 함수 본문이다. B에서도 **처리 순서·반환값·실패 전달을 그대로 두고** 함수명과 완료 callback 이름만 바꾼다. 의존성 주입 부분은 생략했다.

```js
// 인증 적용 뒤 조회를 요청하되 조회 결과는 기다리지 않는다.
// 완료 callback과 반환은 인증 적용을 뜻하며 조회·화면 준비 완료가 아니다.
// 조회 요청·결과의 오류는 onRefreshError로 따로 전달한다.
async function loginAndRefresh(credentials, { onCompleted }) {
  const session = await authenticationService.signIn(credentials);

  try {
    Promise.resolve(requestSessionRefresh()).catch(onRefreshError);
  } catch (error) {
    onRefreshError(error);
  }

  onCompleted(session);
  return session;
}
```

A는 `loginAndRefresh`·`onCompleted`를 유지한다. B는 `signInAndRequestRefresh`·`onSignedIn`으로 바꾼다. 함수 정의 위의 세 주석도 두 안에 똑같이 둔다. 호출부를 나란히 보면 이름이 더하는 정보와 여전히 설명에 맡기는 정보를 비교할 수 있다.

A — 이름 유지와 설명 보완:

```js
function submitLogin(credentials) {
  return loginAndRefresh(credentials, {
    // 인증 적용 완료 알림이다. 조회 결과를 읽는 시점으로 쓰지 않는다.
    onCompleted() {
      showMessage("로그인 완료");
      navigateToTrips();
    },
  });
}
```

B — 개명과 설명 보완:

```js
function submitLogin(credentials) {
  return signInAndRequestRefresh(credentials, {
    // 인증 적용 완료 알림이다. 조회 결과를 읽는 시점으로 쓰지 않는다.
    onSignedIn() {
      showMessage("로그인 완료");
      navigateToTrips();
    },
  });
}
```

### 코드에서 직접 이해할 수 있는 범위를 비교한다

A는 주석을 읽으면 현재 사용에 필요한 경계를 알 수 있다. 그러나 인증 완료와 조회 요청이라는 주요 의미를 주석이 대신 설명한다. 올바르게 사용할 수 있다는 점은 인정하되, 가능한 한 코드 자체로 이해시키려는 기준에서는 개선할 여지가 남는다.

B는 `RequestRefresh`와 `onSignedIn`으로 조회 요청과 인증 완료의 구별을 이름에도 담는다. 호출부를 훑거나 새 callback을 작성할 때 얻는 단서가 늘어난다. 반면 이름이 길어지고 함수·callback의 참조와 관련 문서를 함께 바꿔야 한다. 이 이름만으로 모든 실패 정책을 알 수 있는 것은 아니다. 다른 코드의 타입·흐름으로 드러낼 의미와 별도 설명이 필요한 제약을 구별한다. 여기서는 비교 조건을 맞추기 위해 같은 주석을 두었으며 그 주석 모두를 실제 코드에 남길 필요까지 정한 것은 아니다.

| 판단할 점 | A — 기존 이름과 설명 | B — 새 이름과 같은 설명 |
| --- | --- | --- |
| 현재 소비자를 올바르게 작성할 수 있는가 | 가능하다. 설명이 인증 완료와 조회 완료를 구별한다. | 가능하다. 동작과 설명은 A와 같다. |
| 이름만 훑으면 무엇을 더 알아야 하는가 | refresh와 완료 callback의 정확한 경계를 설명에서 확인한다. | 조회는 요청이고 callback은 인증 완료라는 단서를 이름에서 얻는다. 상세 실패 계약은 여전히 확인한다. |
| 무엇을 바꿔야 하는가 | 이름 참조를 유지한다. 새 사용처에서도 계약 설명을 찾을 수 있게 한다. | 함수·callback 참조와 문서를 바꾼다. 이 예제에서는 내부 두 소비자로 범위가 제한된다. |

**이 조건에서는 B를 권하며 demo도 B를 사용한다.** 인증 완료와 조회 요청이라는 주요 의미를 이름에서 직접 드러내므로 설명에 대한 의존이 줄어든다. 내부 두 소비자라는 조건에서는 그 개선을 막을 큰 호환 제약도 가정하지 않았다. A는 동작 요구를 충족하지만 같은 수준의 명료함을 제공하는 권고안으로 보지는 않는다. 실제 독자의 이해 속도를 측정한 결과는 아니다.

공개 사용처가 많아 호환을 보존해야 한다면 A처럼 이름을 유지하고 설명을 보완하는 절충이 필요할 수 있다. 남는 설명 의존과 전환 비용을 함께 판단한다. B도 코드 명료함의 최종 형태로 확정한 이름은 아니며 책임·API 구성을 더 잘 드러낼 방법이 있다면 다시 비교한다. 새 소비자가 최신 조회 결과를 즉시 사용해야 한다면 두 안 모두 지금의 동작만으로는 부족하다. 그때는 해당 소비자에서 조회를 기다릴지, 공통 완료 계약을 바꿀지 판단해야 한다.

초기의 “로그인과 화면 갱신 완료” 문구는 두 안 모두 “로그인 완료”로 고쳤다. 화면 갱신은 확인하지 않은 결과이므로 문구를 좁혀야 하지만, 그 수정은 함수명 선택과 별개다. 함수 본문과 호출부를 모두 나란히 보려면 [Work 비교 기록](../../../work/workspaces/001-login-completion-names/records/2026-10-19-06-naming-alternatives.md)을 읽는다. 두 전체 코드는 식별자 두 쌍만 다르며 주석·동작은 같다.

## 저장 완료가 필요한 호출은 이름으로 해결할 수 없다

이번에는 `save`가 저장 완료를 약속하고, 호출자가 그 직후 파일을 읽는다고 가정하자. 다음은 이 계약을 어기는 설명용 코드다.

```js
async function save(path, contents) {
  void writeFile(path, contents).catch(reportWriteError);
}

await save(path, contents);
const saved = await readFile(path); // 방금 저장한 내용을 필요로 한다.
```

`await save()`는 쓰기의 완료를 기다리지 않는다. 따라서 읽을 때 새 내용이 준비되지 않았을 수 있고, 쓰기 실패도 `save`를 기다리는 호출자에게 전달되지 않는다. `save`를 `requestSave`로 바꾸고 “접수만 한다”는 주석을 달아도 이 소비자는 여전히 저장한 내용을 읽을 수 있어야 한다.

요구가 그대로라면 쓰기 완료와 실패가 호출자에게 이어지도록 고친다.

```js
async function save(path, contents) {
  await writeFile(path, contents);
}

await save(path, contents);
const saved = await readFile(path);
```

확인할 것도 그 계약이다. 쓰기를 진행 중인 상태에 두었을 때 `save`가 아직 성공하지 않는지, 성공 직후 새 내용을 읽을 수 있는지, 쓰기 실패가 호출자에게 전달되는지를 본다. 이름이 길어졌는지나 주석이 추가됐는지는 이 결과를 대신하지 않는다.

인증 예제에서는 이동·닫기에 필요한 인증 결과를 이미 제공했으므로 A와 B를 비교할 수 있었다. 여기서는 저장 완료라는 필요한 결과가 빠져 있다. 소비자가 접수만 필요하도록 요구가 바뀐다면 다른 설계를 택할 수 있지만, 그것은 현재 계약의 누락을 개명으로 덮는 선택과 다르다.

## 문자열 isError를 유지한 판단

기존 UI 코드에서 Input·Select는 문자열 `isError`의 유무로 오류 스타일을 정하고, 문구 출력은 `Field.Message`에 맡겼다. 같은 계열의 MultiSelect.Trigger는 boolean을 받았다. 아래는 그 차이를 보여 주는 재구성이다.

```tsx
// 관찰한 사용 방식
<Input isError={errorMessage} />
<Field.Message>{errorMessage}</Field.Message>

// Input도 boolean을 받도록 계약을 맞춘다면 가능한 표현
<Input isError={Boolean(errorMessage)} />
<Field.Message>{errorMessage}</Field.Message>
```

두 번째 안은 입력의 `isError` 타입과 오류 표시 계약도 boolean에 맞춘 대안이다. 현재 호출부의 값만 바꾸면 그대로 호환된다고 가정하지 않는다.

boolean이 오류 상태라는 의미를 더 명확하게 드러낸다는 점은 인정했지만, 당시에는 문자열 전달을 중요한 수정 사안으로 보지 않아 변경을 필수로 올리지 않았다. 확인한 판단은 여기까지다. 호환 비용이 컸다거나 오사용이 드물었다는 조사 결과는 없다. 모든 `is` 이름에 문자열을 허용하는 기준이나 모든 사용처의 안전성 검증으로 확대하지 않는다. 당시 판단을 재검토하거나 이후의 코드 명료함 지향과 대조할 때는 [유지 판단의 근거](_background/evidence.md#문자열-iserror의-유지-판단)와 [형성 맥락](_background/context.md#이득과-비용을-나누어-판단하는-이유)을 읽는다.
