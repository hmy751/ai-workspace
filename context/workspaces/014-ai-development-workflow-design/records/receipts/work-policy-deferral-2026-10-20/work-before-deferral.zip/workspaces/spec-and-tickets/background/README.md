# Work 관리 기준의 형성 자료

이 층은 [Workspace 내용 안내](../../README.md)와 [Spec·Ticket·state 작성 기준](../README.md)의 역할·갱신 기준이 만들어진 배경·선택·근거를 보존한다. 현재 관리 방법을 이해하거나 수정할 때 전체 목표와 실행 완료를 구별했던 이유를 복원한다.

- 작은 실행 완료가 전체 목표를 대신하지 않게 한 이유: [현재 형성 맥락](context.md).
- Spec·Ticket 구별을 없애거나 모든 Ticket을 크게 만들지 않은 이유: [기존 선택 기록](records/2026-09-12-goal-and-execution.md).
- 실제로 보존된 문제·사용자 표현·관리 기준: [근거 발췌](evidence.md).
- 이 데모에서 실제 계층을 대조해 바꾼 경위: [로컬 context 정정](../../../../background/records/2026-10-19-ownership-and-local-context.md).

여기는 현재 작업의 실행 이력이 아니다. 과거 검증·운영 연결은 당시 자료의 범위이며, 이 데모가 같은 runtime이나 효과를 갖는 근거가 아니다. 현재 적용은 연결된 본문에서 찾는다.
