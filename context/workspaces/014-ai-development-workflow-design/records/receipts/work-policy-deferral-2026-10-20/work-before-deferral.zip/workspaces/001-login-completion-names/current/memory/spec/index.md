# 인증 적용과 조회 완료를 구별하는 작업 정의

이번 Work는 호출자가 이름·callback·안내에서 인증 적용과 조회 갱신 완료를 혼동하지 않도록 작은 실행 예제를 구성한다. 현재 선택은 기기 저장·상태 공개 뒤 조회를 요청하되 조회 완료는 기다리지 않고 인증 완료를 전달하는 것이다. Login·Reauth는 최신 조회 값을 callback에서 직접 사용하지 않는 조건이다.

이 선택은 실제 Noline 제품의 개명이나 통합 완료를 뜻하지 않는다. 초기 가정에서 새 메모리 예제를 작성한 작업이며, 개인 기준·제품 계약·이 Work의 적용 선택은 각 영역의 책임을 유지한다.

| 지금 확인할 것 | 이 Spec의 분할 본문 |
| --- | --- |
| 무엇을 해결하고 어디까지 다루나 | [문제·목표·범위](index.problem-goal-scope.md) |
| 조건별로 어떤 결과가 달라지나 | [요구 동작과 사례](index.behavior-and-cases.md) |
| 입력·완료·오류에 무엇을 약속하나 | [개념·입출력 계약](index.concepts-and-contracts.md) |
| 무엇을 확인해야 목표를 이뤘다고 보나 | [품질과 완료 판단](index.quality-and-completion.md) |
| 왜 현재 이름·대기 방식을 쓰고 무엇이 미정인가 | [제약·설계·가정](index.constraints-design-assumptions.md) |

다섯 관점은 하나의 작업 정의를 나누어 설명한다. 실행 분해는 [Ticket](../tickets/index.md)이, 전체 진행과 다음 행동은 [state](../../state/index.md)가 맡는다. 정의의 목적·선택을 재검토할 때는 [구성 안내](README.md)에서 형성 자료를 찾는다.
