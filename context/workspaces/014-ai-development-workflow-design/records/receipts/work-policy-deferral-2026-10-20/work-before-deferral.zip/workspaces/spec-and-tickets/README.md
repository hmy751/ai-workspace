# Work의 Spec·Ticket·state

작업 정의·개별 실행·전체 상황을 구별해 다음 행동에 필요한 내용을 찾는다. 각 Workspace의 `current/memory/spec/` 시작 본문과 다섯 관점의 분할 본문이 하나의 Spec이다. 관점이 다섯이라는 이유로 작업을 다섯 Ticket으로 나누지는 않는다.

- `index.problem-goal-scope.md`: 해결할 문제, 얻을 결과, 포함·제외 범위
- `index.behavior-and-cases.md`: 요구 동작과 결과가 달라지는 대표 사례
- `index.concepts-and-contracts.md`: 함께 이해해야 할 의미·입출력·오류 계약
- `index.quality-and-completion.md`: 결과를 이뤘다고 판단할 근거. 동작 보존과 개선 효과를 구별한다.
- `index.constraints-design-assumptions.md`: 지킬 제약, 현재 선택과 이유, 아직 확인할 가정

Ticket은 그 목표 안에서 한 번의 실행이 맡는 결과, 필요한 맥락·접근, 완료 조건·확인 방법, 현재 상태·실제 결과를 함께 남긴다. 같은 본문의 현재 상태를 갱신하고 상세 이력은 records에서 찾게 한다. 색인은 위치와 맡은 일을 안내하며 별도의 진행 상태 정본이 되지 않는다.

`current/state/index.md`는 Work 전체의 현재 상황과 다음 행동을 종합한다. 모든 Ticket의 정의와 상세 이력을 복제하지 않는다. 작업 담당자는 새 근거가 목표·계약·선택을 바꾸는지 판단해 해당 Owner를 고친다. 완료된 동작과 사용자 수락·제품 통합은 같은 상태가 아니다.

이번 예시는 [로그인 완료 표현 Work](../001-login-completion-names/README.md)에서 이 역할별 내용을 확인할 수 있다.

이 역할 구별을 만든 문제·선택·근거를 확인하거나 기준을 바꿀 때는 [형성 자료 안내](background/README.md)를 읽는다. 실제 작업의 Spec·Ticket 본문과 현재 상태는 각 Workspace에 유지한다.
