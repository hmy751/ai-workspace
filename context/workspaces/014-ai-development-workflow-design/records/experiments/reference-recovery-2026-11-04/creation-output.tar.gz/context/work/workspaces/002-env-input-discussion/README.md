# 환경 변수 입력 지원 논의

환경 변수로 요청 정책을 입력하는 기능이 필요한지, 지원한다면 어떤 사용자 문제와 입력 계약을 다뤄야 하는지 논의하기 위한 독립 Work다. 현재는 논의할 근거와 열린 질문을 준비한 단계이며, 지원 채택·제품 구현은 요청되지 않았다. 기존 `001-default-timeout`의 목표나 남은 수락 판단을 이 Work로 옮기지 않는다.

[재개 안내](recover.md)에서 이번 논의의 초점과 읽을 자료를 찾는다. 기본 Workspace 선택은 [목록](../README.md)의 `001-default-timeout`을 유지한다.

- [current의 memory](current/memory/index.md)는 논의 목표·보존 조건·열린 선택과 선택한 Project·Personal 맥락을 소유한다. [state](current/state/index.md)는 현재 준비 상태와 다음 행동을 설명한다.
- [source](source/index.md)는 사용자 요청 원문과 재접근 근거를 보존한다.
- [output](output/index.md)은 이 Work가 만들어 선택한 논의 결과를 연결한다. 초기 준비 문서는 제품 지원 결정이나 구현 결과가 아니다.
- [records](records/README.md)는 생성에서 선택·제외한 의미와 인수 확인 근거를 남긴다.

관리 책임과 갱신은 [Work 지침](../../AGENTS.md)과 [Spec·Ticket 기준](../spec-and-tickets/README.md)을 따른다. 제품 정책의 결정권은 사용자 또는 명시된 제품 책임자에게 남는다.
