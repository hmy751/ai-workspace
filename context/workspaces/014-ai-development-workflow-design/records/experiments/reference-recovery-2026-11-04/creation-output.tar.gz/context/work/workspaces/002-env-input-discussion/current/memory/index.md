# 논의의 현재 정의

환경 변수 입력을 지원할지 판단할 논의를 준비한다. 기존 계약은 판단의 출발점이고, 새로운 입력 정책은 아직 정하지 않았다.

- [문제·목표·범위](spec/01-problem-goal-scope.md)
- [요구 동작과 대표 사례](spec/02-behavior-and-cases.md)
- [핵심 개념·입출력 계약](spec/03-concepts-and-contracts.md)
- [품질·완료 판단](spec/04-quality-and-completion.md)
- [제약·현재 설계·가정](spec/05-constraints-design-assumptions.md)
- [선택한 Project·Personal 맥락](project-context.md): 기존 제품 의미와 이번 논의에 적용할 관점·원문 접근점
- [Ticket 색인](tickets/index.md): 아직 실행 Ticket 없음

전체 상황과 첫 행동은 [state](../state/index.md), 읽을 범위는 [재개 안내](../../recover.md)가 맡는다.
