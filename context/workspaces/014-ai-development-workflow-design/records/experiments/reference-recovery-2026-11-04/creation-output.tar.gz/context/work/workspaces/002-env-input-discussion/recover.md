# 환경 변수 입력 논의를 이어 갈 때

현재 초점은 환경 변수 지원의 필요성과 논의할 계약을 확인하는 것이다. 기본 작업은 유지되며, 이 Work를 명시해서 읽는 것만으로 제품 지원 범위나 다음 일반 재개의 기본 선택이 바뀌지 않는다.

## 일반 재개에서 먼저 읽을 자료

1. [목표·범위](current/memory/spec/01-problem-goal-scope.md)와 [품질·완료 판단](current/memory/spec/04-quality-and-completion.md): 이번 준비 요청의 완료와 앞으로의 논의 완료를 구별한다.
2. [현재 상태](current/state/index.md): 실제로 한 일·미확인·첫 대화를 확인한다.
3. [선택한 맥락](current/memory/project-context.md): 기존 제품 계약과 논의에 적용할 Personal 관점을 이유와 함께 읽는다. 이 문서가 고른 원문 중 현재 기준을 판단할 본문으로 이어간다.
4. [산출물 지도](output/index.md): 지원 결정이나 구현 결과가 아직 없음을 확인한다.

## 질문에 맞춰 추가할 자료

- 환경 변수의 의미·입력 조합을 구체화할 때 [대표 사례](current/memory/spec/02-behavior-and-cases.md)와 [개념·계약](current/memory/spec/03-concepts-and-contracts.md)을 읽는다. 사례는 논의 질문이며 채택된 동작이 아니다.
- 지원 여부나 구현 방향을 결정하려 할 때 [제약·설계·가정](current/memory/spec/05-constraints-design-assumptions.md)과 [요청 원문](source/index.md)을 읽어 현재 권한과 미정 범위를 확인한다.
- 현재 구현의 지원 경계를 대조할 때에는 [선택한 맥락](current/memory/project-context.md)의 실제 코드·테스트 접근점을 사용한다. 문서와 코드 읽기는 제품 테스트 실행과 구별한다.
- 준비 과정이나 확인 범위를 재검토할 때 [생성 기록](records/2026-11-04-workspace-creation.md)을 읽는다. 기존 Work 전체를 순서대로 읽을 필요는 없다.

한정된 질문을 맡은 담당자는 해당 Spec과 근거에서 시작하고 필요한 조건만 추가한다. 전체 일반 재개의 읽기 목록을 반복하지 않는다. Ticket이 필요해지면 [memory 색인](current/memory/index.md)에서 실행 범위를 연결한다.
