---
name: create-context-workspace
description: 이미 Context Harness가 설치된 Project 안에서 새 독립 Workspace를 만들거나 기존 Workspace의 후속 작업을 새 Workspace로 분리할 때 사용한다. "001에 이어 002를 만들어줘", "이 작업을 새 Workspace로 넘겨줘"처럼 새 Workspace 생성이 요청되면 적용한다. Context Harness 최초 이식, 기존 Workspace 단순 재진입·수정, Project context 반영만 요청한 경우에는 사용하지 않는다.
---

# Create Context Workspace

## 책임

이 skill은 이미 설치된 Project에서 새 Workspace를 구성하고 bounded 재진입을 검토하는 실행 장치다. 지속 원칙은 [`새 Workspace 생성과 전환`](../../../context/work/workspaces/CREATE-AND-TRANSITION.md)이 소유한다. 이 skill에 그 원칙이나 live schema를 별도 정본으로 복제하지 않는다.

최초 Context Harness 이식과 첫 Workspace 생성은 `apply-context-harness`의 책임이다. 이 skill은 설치 뒤 두 번째 Workspace부터 사용하며, 기존 Workspace의 단순 재진입·current 갱신이나 Project context 반영만을 위해 발동하지 않는다.

목적·prototype과 설치 대상의 차이·의미 계승을 재검토할 때 [형성 자료](_background/README.md)를 읽는다. 아래 기계 계약은 유지하고 전환은 현재 Work 계약을 따른다.

## 시작

1. 사용자 지정 대상 Project를 먼저 확인하고 그 경로에서 `git rev-parse --show-toplevel`과 root 지침을 대조한다. 이 스킬의 설치 경로나 현재 shell 위치를 대상 Project로 가정하지 않는다. Root [`AGENTS.md`](../../../AGENTS.md), [`context/README.md`](../../../context/README.md), [`Project context`](../../../context/project/README.md), [Project 읽기 기준](../../../context/project/REFERENCE/reading.md), [`Work context`](../../../context/work/README.md), [`Workspace collection`](../../../context/work/workspaces/README.md)과 생성·전환 canonical을 끝까지 읽는다. Project의 주제별 진입이나 세 물리 layer가 없으면 새 Workspace 생성 중 임의로 보수하지 않고 Project context repair가 필요한 설치 상태로 분리해 알린다.
2. 적용되는 instruction, Git 상태와 새 Workspace exact path의 기존 파일·symlink를 확인해 사용자 변경과 이름 충돌을 보호한다. 기존 Workspace나 같은 이름의 skill·폴더를 덮어쓰지 않는다.
3. 요청이 무관한 새 작업인지 특정 predecessor의 후속인지, 새 goal·완료 장면·범위·Workspace id가 무엇인지 판단한다. 결과를 바꾸는 정보가 없고 안전하게 추론할 수 없을 때만 한 번에 묻는다. 후속 관계를 표현하려고 새 parent schema를 만들지 않는다.

## 생성

1. 이미 유효하게 확보한 맥락은 재사용하고 필요한 원문을 [USAGE](../../../context/USAGE.md)로 선택한다. 생성·전환 canonical과 Project 읽기 기준에 따라 `context/project/README.md`의 작업·주제별 진입에서 현재 goal의 판단을 바꾸는 실제 본문과 관련 Decision을 고른다. 물리 layer를 먼저 분류하거나 모든 layer README를 일괄 읽지 않는다. README만 내용 payload로 삼거나 predecessor 전체를 복제·수정하지 않는다.
2. Live Workspace collection과 Harness contract에서 현재 machine shape를 확인한다. 유효한 기존 Workspace는 구조 참고로만 사용하고 sample goal·source·검증 값·receipt를 복사하지 않는다.
3. 새 Workspace의 사람용 진입점, machine identity와 Recover·Verify 계약, current·source·output·records를 새 goal에 맞게 구성한다. `recover.json`에는 Project root README와 goal에 필요한 `common/`, `current/`, `guidance/`, `decisions/` 아래 실제 문서만 이유와 함께 선택한다. 모든 layer를 자동 선택하지 않고, Verify의 canonical basis는 Recover 선택과 별도로 claim의 normative Owner에서 고른다. 제품 Verify를 아직 실행하지 않았다면 status에서 receipt·pass·완료를 가장하지 않는다.
4. 목표·보존 조건·현재 결과·첫 판단을 새 진입점만으로 이해할 수 있게 구성한다. 생성 중 새 제품 약속이나 기존 권한 밖의 선택이 필요하면 Main의 판단으로 연결하며 생성 권한으로 대신 결정하지 않는다. 다음 세션의 판단을 바꾸는 의미는 successor current의 적절한 Owner에 직접 쓴다. 특정 원문을 먼저 읽어야 하면 current와 source에 exact canonical 접근점, 역할, 이유와 읽을 시점을 남긴다.
5. Detailed predecessor output·record·source는 필요한 것만 단방향으로 연결한다. 의도적으로 이어받지 않은 범주는 오해가 현재 판단을 바꿀 때만 bounded하게 적고, Project-wide 후보는 Project context Owner의 별도 판단 없이 승격하지 않는다. 생성 중 Project path·책임·authority 자체를 바꿔야 하면 먼저 그 Owner 변경을 분리하고 생성·전환 canonical이 정의한 live consumer를 reconcile한다. 보통의 Workspace 생성은 Project 전체 scan을 요구하지 않는다.

## 검토

1. 새 Workspace id를 명시해 bounded Recover를 실행한다. 기본 active index에 의존하지 않는다. Project Owner를 함께 바꿨다면 모든 영향받는 live consumer의 explicit Recover와 id 없는 active/default Recover도 실행한다.
2. 가능하면 새 read-only 주체에게 Recover packet만 주고 goal·제약·첫 판단·다음 행동·필수 원문 접근점을 설명하게 한다. 선택된 Project 문서가 대표 작업에 필요한 의미·계약·현재 차이를 실제로 제공하는지, current의 machine Owner 설명과 `output/index.md`의 링크가 실제 canonical을 가리키는지도 판정하게 한다. 생성자의 결론이나 predecessor 자료를 함께 주지 않는다. 별도 주체가 없으면 packet 밖 자료를 다시 열지 않는 자체 검토로 대체하고 증거가 더 약함을 보고한다.
3. 필수 의미·접근·첫 행동을 복원하지 못하면 인수 확인은 미완료다. 검토가 실패하면 Recover 범위를 넓히거나 predecessor를 수정하지 않고 successor current와 source 선택을 보완한 뒤 다시 확인한다.
4. Live schema·local link·JSON·instruction과 관련 Harness 검사를 변경 위험에 맞춰 실행한다. Local link의 존재와 설명에 맞는 semantic target을 구분하고, sample·rename 잔재를 검사한다. 제품 Verify는 실제 제품 상태 전환 증거가 필요할 때만 실행하며 argv가 읽는 tracked input closure를 먼저 확인하고, pass를 acceptance나 완료로 바꾸지 않는다.

## 활성화와 보고

생성만 요청받았으면 `workspaces/index.json`과 현재 대화의 작업 대상을 바꾸지 않는다. 전환도 요청됐으면 생성·전환 canonical에 따라 원래 Work 기록의 진행·미반영 사항, 새 Work의 현재 의미와 실제 배정을 확인한다. 지속 전환의 기본 index와 이번 대화의 대상은 구별한다. [record-work](../record-work/SKILL.md)의 담당자에게 대상·입력 구간을 새로 배정하며 옛 activation이나 session binding 명령을 실행하지 않는다.

마지막에는 다음을 짧게 보고한다.

- 새 Workspace id와 독립/후속 관계
- current에 직접 남긴 핵심 의미와 필수 source 접근점
- 단방향 참조와 의도적 비상속 범위
- bounded Recover와 독립 재진입 검토 결과
- 기본 index·이번 대화의 대상·기록 배정 변경 여부와 실제로 확인하지 않은 host 범위
- commit 여부와 보호한 기존 변경

사용자가 명시하지 않으면 stage·commit하지 않는다.
