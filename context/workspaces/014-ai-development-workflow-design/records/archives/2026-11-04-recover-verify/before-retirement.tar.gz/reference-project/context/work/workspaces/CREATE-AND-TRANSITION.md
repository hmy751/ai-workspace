# 새 WORKSPACE 생성과 전환

이 문서는 이미 Context Harness가 설치된 Project에서 새 Workspace를 만들고 다음 세션이 독립적으로 재진입할 수 있게 준비하는 전체 계약의 canonical이다. Workspace collection과 각 내부 Owner의 의미는 [`README.md`](README.md)가 소유하고, 이 문서는 생성·전환 동작의 시작 조건, 의미 선별, 산출물, 검토와 활성화 경계를 소유한다.

Repo-local [`create-context-workspace` skill](../../../.agents/skills/create-context-workspace/SKILL.md)은 이 계약을 적용하는 교체 가능한 관리 장치다. Skill을 사용하지 않거나 제거해도 사람이나 다른 AI가 이 문서를 따라 같은 책임을 수행할 수 있어야 하며, skill 문장을 이 계약의 두 번째 정본으로 사용하지 않는다.

새 Workspace의 사람용 문서를 구성할 때는 [문서 작성과 갱신](DOCUMENT-WRITING.md)을 직접 읽고 적용한다. 글의 내용 충분성·구성·표현은 해당 지침을 따르며, 생성 범위와 아래의 전환·검토 책임은 이 계약이 소유한다.

## 시작 조건과 책임

서로 무관한 작업을 새 Workspace로 시작하거나, 현재 작업에서 이어지는 새 goal을 후속 Workspace로 분리할 때 적용한다. 기존 Workspace에 재진입하거나 그 Workspace 안의 current를 갱신하는 일에는 적용하지 않는다.

- 사람은 새 goal, 완료 장면, 범위, 중요한 source 권위, Project 전체 반영과 acceptance를 결정한다.
- Main 또는 이 계약을 적용하는 skill은 새 goal을 해석하고 필요한 현재 의미를 선별해 새 Workspace의 기존 Owner 구조에 배치한다.
- Workspace schema와 Harness validation은 id·shape·경로·파일 안전처럼 명시 가능한 조건만 검사한다. 중요한 의미가 빠지지 않았다는 보장은 하지 않는다.
- Recover는 완성된 bounded packet을 읽고, record-work의 담당자는 지정 Workspace 하나 안의 변화를 기록한다. 둘 다 새 Workspace 생성, predecessor 탐색과 Workspace 사이 동기화를 소유하지 않는다.

새 Workspace는 predecessor의 다음 번호이거나 후속 작업이어도 자기 goal과 current를 소유하는 독립된 지속 단위다. 서로 무관한 새 작업에는 predecessor 관계를 만들지 않는다.

## 생성 workflow

1. 사용자가 정한 새 goal, 완료 장면, 범위와 하지 않을 것을 먼저 고정한다. 새 Workspace id나 goal을 안전하게 추론할 수 없거나 검증 기준·source 권위의 선택이 결과를 바꾼다면 관련 write 전에 사용자에게 묻는다.
2. [Project 읽기 기준](../../project/REFERENCE/reading.md)에 따라 `context/project/README.md`의 작업·주제별 진입에서 새 goal의 판단을 바꾸는 실제 본문과 관련 Decision을 선택한다. Root와 layer README 자체를 충분한 내용 payload로 보지 않으며 물리 layer를 먼저 분류하거나 모두 읽지 않는다. 그 뒤 새 goal에 실제로 이어지는 predecessor의 current, 선택된 output, 정확한 source와 필요한 record만 확인하며 관련 이유가 없는 다른 Workspace를 넓게 탐색하지 않는다.
3. 후보마다 그것을 모르면 새 goal, 계속 지킬 제약, 첫 판단, 현재 산출물의 의미 또는 다음 행동이 달라지는지 판단한다. 지금도 유효한지, 원문을 직접 다시 읽어야 하는지, 실제 canonical과 Owner가 어디인지 함께 확인한다.
4. 다음 재진입에 계속 적용되는 의미는 링크로 대신하지 않고 새 Workspace의 적절한 current Owner에 직접 서술한다. [Spec과 Ticket](spec-and-tickets/README.md)에 따라 Work당 하나의 Spec을 다섯 파일로 구성한다. Work의 결과·공통 계약·품질 기준·제약과 공통 설계는 Spec에, 이번 실행의 결과·범위·맥락·설계·확인 방법과 진행·실제 결과는 필요한 Ticket에, 전체 상황과 다음 행동은 사람용 state에 둔다. Spec의 각 관점을 조사·논의로 구체화하되 미정 부분은 가정·열린 판단으로 드러내고 근거 없이 채우지 않는다. Ticket이 아직 없으면 색인에 없다고 적고 빈 작업을 만들어 채우지 않는다. 초기 구성은 Main/생성 skill이 맡고 이후 문서 유지에는 Spec·Ticket의 Main·기록 담당자의 갱신 관계를 적용한다.
5. 원문 전체가 기본 current에는 불필요하지만 특정 판단 전에 직접 읽어야 한다면 `source/index.md`에 원래 canonical과 provenance를 선택한다. Recover가 읽는 current에도 exact canonical 경로나 직접 링크, 문서의 역할, 필요한 이유와 읽을 시점을 함께 남긴다. Source나 current의 링크만으로 필수 재진입 의미 자체를 대신하지 않는다.
6. Predecessor만 소유하는 당시 선택 이유나 상세 과정은 복제하지 않고 exact output·record·source를 단방향으로 가리킨다. 관련 있어도 새 goal의 판단과 행동을 바꾸지 않는 과거 상태, 세부 과정, 후보와 실행 기록은 predecessor에 그대로 둔다.
7. 과거의 특정 범주가 successor에도 계속 적용된다고 오해할 가능성이 있고 그 오해가 현재 판단을 바꾼다면, 빠진 파일을 전부 열거하지 않고 그 범주와 지금 적용하지 않는 이유·현재 영향만 successor current에 적는다. 선택·제외 판단을 나중에 재검토할 필요가 있으면 새 Workspace record에 남긴다.
8. [`Workspace 내부 경계`](README.md#workspace-내부-경계)에 맞춰 사람용 진입점, machine identity와 Recover·Verify 계약, current·source·output·records를 완성한다. 기존 Workspace의 파일이나 값을 통째로 복제하지 않고, live schema와 새 goal에 맞는 root Project routing anchor·실제 본문 선택·검증 claim·evidence·상태를 각각 구성한다. `recover.json`의 Project 선택은 root README와 허용된 `common/`, `current/`, `guidance/`, `decisions/` 경로만 사용하며 `MAINTENANCE.md`와 `REFERENCE/`를 일반 제품 작업의 기본 입력으로 추가하지 않는다. 사람용 current는 `workspace.json`의 identity, `recover.json`의 선택, `verify.json`의 실행 계약, `status.json`의 마지막 결과·receipt cursor와 Recover가 계산하는 freshness를 혼동하지 않는다. 아직 제품 Verify를 실행하지 않았다면 machine status는 receipt나 성공을 가장하지 않는다.

## Workspace 사이의 참조 경계

- Successor는 predecessor의 `current/` 전체를 live dependency로 삼지 않는다. 현재 적용되는 의미는 자기 current에 소유하고, 상세 근거만 정확한 canonical이나 predecessor의 exact artifact로 연결한다.
- 두 Workspace 사이에 자동 전파, 상호 갱신이나 역전파를 만들지 않는다. Predecessor가 나중에 바뀌어도 successor가 자동 추종하지 않으며, 영향이 생기면 successor가 원래 canonical과 현재 사실을 다시 대조해 자기 current를 갱신한다.
- 과거 Workspace의 상세 근거를 읽을 수는 있지만, 다른 Workspace의 current를 차례로 복구해야만 이해되는 계승 사슬은 만들지 않는다.
- 이 관계를 표현하기 위해 필수 `parent_workspace_id`, 공통 handoff 문서, 새 schema·hook이나 동기화 장치를 전제하지 않는다.
- Workspace 밖 Project 전체에도 적용될 수 있는 사실은 Project context 후보로만 다룬다. 실제 반영은 [`Project context`](../../project/README.md)의 상세 Owner와 source 권위가 Project 전체 적용을 뒷받침하는지 별도로 판단한 뒤 그 Owner가 결정한다. 여러 Workspace가 사용했다는 사실만으로 승격하지 않는다.

## Bounded 재진입 검토

생성한 Workspace를 작업 대상으로 전환하기 전에 predecessor를 보지 못한 새 주체에게 그 Workspace의 explicit bounded Recover packet만 제공하고 다음을 확인한다.

- Spec의 목표·제약·완료 기준, Workspace의 실제 상태와 다음 판단을 설명할 수 있는가. Ticket 색인에서 필요한 실행 본문을 찾을 수 있는가.
- 이전 작업에서 현재 의미로 이어받은 것과, 계속 적용된다고 오해할 수 있지만 의도적으로 이어받지 않은 범주를 구분할 수 있는가.
- 추가 원문이 필요하다면 exact 접근점, 역할, 이유와 어느 판단 전에 읽을지를 알 수 있는가.
- Project routing anchor 밖에서 이 goal의 대표 작업에 필요한 제품 의미·계약·현재 차이와 Decision을 설명할 실제 선택 문서와 이유가 있는가. 세 layer를 모두 선택했다는 사실로 이를 대신하지 않는가.
- Current와 output의 local target이 존재하며, label·주변 설명이 말하는 실제 Owner를 가리키는가.
- Predecessor 전체를 다시 Recover하거나 연쇄적으로 거슬러 올라가지 않고 첫 행동을 시작할 수 있는가.

가능하면 생성자의 warm 이해를 공유하지 않는 별도 주체가 검토한다. 별도 주체를 사용할 수 없으면 생성자가 packet 밖 자료를 다시 열지 않고 같은 질문을 점검하되 더 약한 증거임을 밝힌다. 부족하면 Recover가 과거를 더 읽게 하지 않고 successor의 current와 Project·source 선택을 보완한다. 파일 존재와 schema validation만으로 의미 충분성이나 semantic target을 통과했다고 주장하지 않는다.

새 Workspace 생성과 함께 Project 문서의 path·책임·authority도 바꿨다면 [`Workspace collection 계약`](README.md#project-context-변경과-live-consumer)의 영향을 받는 live consumer를 함께 reconcile한다. 단순 Workspace 생성만으로 Project 전체 consumer scan을 요구하지 않는다.

## 생성과 전환의 경계를 구별한다

생성만 요청받았으면 `workspaces/index.json`의 기본값과 이번 대화의 작업 대상을 바꾸지 않는다. 준비된 Workspace로 전환할 때 Main은 그 목표·현재 의미를 인수하고, 요청이 이번 대화에만 해당하는지 이후 일반 재개의 기본값까지 바꾸는지 구별한다. 지속 전환 요청이면 기본 index도 맞추고 명시 Recover와 필요하면 기본 Recover로 실제 선택을 확인한다.

전환 전에 원래 Work의 기록 담당자가 수행 중인 수정·반환과 미반영 사항을 확인한다. 새 목표·제약·첫 판단에 영향을 주는 의미는 원래 Work의 기록을 마치거나 새 Work가 알아야 할 의미를 직접 구성한다. 관련 없는 미완료가 있다는 이유로 모든 전환을 막지는 않는다. 늦은 결과는 원래 배정과 입력 구간에 귀속하며 새 대상의 결과로 합치지 않는다.

같은 Main 대화를 이어 쓸 수 있다. 기록 담당자를 이어 쓰면 새 대상·원문 구간·기존 미반영 책임을 명시하고, 다른 담당자를 쓰면 실제 문서와 필요한 원문에서 인수한다. 자동 session binding·activation CLI·hook을 실행하지 않는다. 실제 배정 변경, index 기본값 변경, 문서 준비와 host의 대화 상태는 구별한다.

## 완료와 증명 상한

생성 책임은 새 Workspace의 구조와 현재 의미를 구성하고 bounded 재진입 검토 결과를 보고하는 데서 끝난다. 사람의 acceptance, Workspace 완료·보관, Project context 반영과 commit은 각각 별도 권한이다.

Repo-local skill과 검토 절차는 의미 누락 가능성을 줄이지만, 자동 skill 선택, 자동 의미 선별, 의미 충분성이나 actual host 활성화를 결정적으로 보장하지 않는다. 반복되는 구조 오류가 실제로 확인되기 전에는 이 의미 판단을 새 schema나 생성 script로 고정하지 않는다.
