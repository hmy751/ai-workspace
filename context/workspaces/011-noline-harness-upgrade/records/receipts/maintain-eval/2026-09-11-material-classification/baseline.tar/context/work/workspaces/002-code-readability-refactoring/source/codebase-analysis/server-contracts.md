# 서버와 공유 계약

[전체 목차와 분석 범위](README.md)

> 2026-09-06 분석 기록 · 기준 코드: `b4ed41f6e4bbae26fd45827b3b9063097a2c1ea4`
> 2026-09-08에 카테고리별로 분리했다. 관찰과 검증 결과는 원래 분석 시점 기준이다.

## 같은 조회라도 소유권·삭제 조건이 다르다

`GET /api/schedules?tripId=...`는 현재 사용자와 삭제 제외 조건을 적용한다. `GET /api/trips/:tripId/schedules`는 인증 후 tripId만으로 조회하며, 사용자 소유권과 삭제 제외 조건이 없다. 이는 단순 문체가 아니라 확인된 조회 조건 결함이다.

일정·경비 생성에서도 입력받은 부모 tripId·scheduleId의 소유권을 별도로 확인하지 않는 경로가 있다. 사용자 데이터에 대한 실제 API 호출 재현은 수행하지 않았다.

근거: [일반 일정 조회](../../../../../../apps/server/src/routes/schedules.ts) 75행, [여행 아래 일정 조회](../../../../../../apps/server/src/routes/trips.ts) 325행, [일정 생성](../../../../../../apps/server/src/routes/schedules.ts) 27행, [경비 생성](../../../../../../apps/server/src/routes/expenses.ts) 89행.

## 같은 데이터의 응답 변환이 API별로 다르다

경비 CRUD와 sync pull은 hasReceipt를 정수에서 boolean으로, date를 날짜 문자열로 바꾼다. 여행 활성화 응답은 이 변환 일부가 빠져 있으며 `validatedExpenses`라는 이름과 달리 해당 위치에서 Zod 검증도 하지 않는다. 활성화 API는 실제 client 활성화 흐름에서 사용한다.

공유 schema가 있어도 각 응답 경계에 적용하지 않으면 같은 경비가 다른 형태로 전달될 수 있다. 변환 차이는 확인했고 실제 활성화 중의 영향은 재현하지 않았다.

근거: [경비 응답](../../../../../../apps/server/src/routes/expenses.ts) 111행, [pull 변환](../../../../../../apps/server/src/routes/sync.ts) 115행, [활성화 응답](../../../../../../apps/server/src/routes/trips.ts) 458행, [client 활성화 호출](../../../../../../apps/client/src/entities/trip/data/useActivateTrip.ts) 55행.

## 검증을 통과하는 입력과 실제 반영하는 필드가 다르다

여행 수정 schema는 latitude·longitude·cityId를 허용하지만, 서버 PUT은 이 필드를 꺼내거나 갱신하지 않고 성공 응답을 반환한다. 입력 허용과 변경 반영 사이의 불일치다.

근거: [허용 필드](../../../../../../packages/schema/src/requests/trip.ts) 44행, [서버 수정](../../../../../../apps/server/src/routes/trips.ts) 184·200행.

## 오류 응답의 형태와 변환 책임이 여러 갈래다

auth는 `success: false` 아래 error 객체, CRUD helper는 error·message·details, 최종 error middleware는 message·code 형태를 사용한다. Places는 middleware로 오류를 넘기고 CRUD는 catch에서 직접 응답한다.

호출자는 실패 종류와 메시지를 읽는 위치를 경로마다 확인해야 한다. console 정리와 함께 살펴볼 수 있으나, 오류 계약 변경은 표시와 재시도까지 영향을 주므로 단순 출력 삭제와 구분한다.

근거: [auth 오류](../../../../../../apps/server/src/middleware/auth.ts) 32행, [CRUD helper](../../../../../../apps/server/src/utils/http-errors.ts) 3행, [최종 middleware](../../../../../../apps/server/src/middleware/errorHandler.ts) 14행.
