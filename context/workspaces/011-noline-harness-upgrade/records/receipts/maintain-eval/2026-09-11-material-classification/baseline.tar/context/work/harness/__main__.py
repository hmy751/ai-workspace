"""Thin ``python -m context.work.harness`` entrypoint."""

from .cli import main


if __name__ == "__main__":
    raise SystemExit(main())
