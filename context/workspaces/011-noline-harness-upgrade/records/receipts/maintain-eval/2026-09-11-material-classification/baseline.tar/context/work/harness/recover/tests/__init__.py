"""Recover responsibility tests."""
