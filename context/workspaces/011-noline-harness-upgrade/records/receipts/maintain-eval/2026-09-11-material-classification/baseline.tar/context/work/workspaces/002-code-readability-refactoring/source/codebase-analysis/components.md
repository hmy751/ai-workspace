# 컴포넌트 내부 흐름

[전체 목차와 분석 범위](README.md)

> 2026-09-06 분석 기록 · 기준 코드: `b4ed41f6e4bbae26fd45827b3b9063097a2c1ea4`
> 2026-09-08에 카테고리별로 분리했다. 관찰과 검증 결과는 원래 분석 시점 기준이다.

## 입력 초기화와 값 변경의 이유가 여러 실행 시점에 나뉜다

일정 생성은 렌더링 중 날짜 설정, 장소 선택 이벤트, hook effect를 통한 폼 값 복사가 함께 있다. 수정 Drawer들은 항목 ID가 바뀔 때 여러 `setValue`를 실행한다.

취소, 다른 항목 선택, 재진입, 늦게 도착한 조회 결과에서 입력을 보존할지 버릴지 이해하려면 여러 위치를 읽어야 한다. 각 방식이 모두 잘못됐다는 판정은 아니다.

근거: [일정 생성 화면](../../../../../../apps/client/src/screens/CreateScheduleScreen.tsx) 78·96행, [장소 값 반영](../../../../../../apps/client/src/features/schedule/create-schedule/useCreateScheduleForm.ts) 33행, [경비 수정 초기화](../../../../../../apps/client/src/features/expense/update-expense/UpdateExpenseDrawer.tsx) 73행.

## callback 이름과 실행하는 행동이 다르다

TimePicker는 선택 callback 다음 닫기 callback을 호출한다. 화면은 `onClose`에도 시간 선택 함수를 연결한다. 이 함수는 값을 저장·검증하고 picker를 닫는다. DatePicker에도 같은 연결이 있다.

```tsx
onClose={() => handleSelectTime(watch('time') || '09:00')}
onSelectTime={handleSelectTime}
```

닫기와 선택의 의미가 겹쳐, 이름만 보고 실행을 예상하기 어렵다. 잘못된 시간 저장이 실제로 발생했다는 재현 결과는 없다.

근거: [TimePicker](../../../../../../apps/client/src/shared/components/TimePicker/TimePicker.tsx) 27행, [화면 연결](../../../../../../apps/client/src/screens/CreateScheduleScreen.tsx) 209·218행, [선택 함수](../../../../../../apps/client/src/features/schedule/create-schedule/useCreateScheduleForm.ts) 54·59행.

## 저장 이후 작업과 화면 이동의 책임이 기능마다 다르다

여행 생성 hook은 직접 화면을 이동한다. 경비 생성 hook은 callback 실행 뒤 뒤로 이동한다. 일정 생성 hook은 화면 이동을 callback에 맡기면서 500ms 후 경로 준비를 별도로 예약한다. 일정 수정도 후속 경로 준비를 자체 구현한다.

같은 ‘저장 성공’을 읽어도 완료 후 무엇이 끝났고 무엇이 계속 실행되는지 확인하는 위치가 달라진다. 타이머를 사용해야 하는 이유와 후속 실패의 처리 주체는 추가 확인이 필요하다.

근거: [여행 생성](../../../../../../apps/client/src/features/trip/create-trip/useCreateTripForm.ts) 69행, [경비 생성](../../../../../../apps/client/src/features/expense/create-expense/useCreateExpenseForm.ts) 59행, [일정 생성](../../../../../../apps/client/src/features/schedule/create-schedule/useCreateScheduleForm.ts) 83행, [일정 수정](../../../../../../apps/client/src/features/schedule/update-schedule/UpdateScheduleDrawer.tsx) 120행.

## 비슷한 입력과 표시를 별도로 구현하며 차이가 생겼다

생성은 별도 form hook으로 검증·저장을 묶지만, 수정은 Drawer에 조회·입력·저장·알림을 함께 둔다. 경비 생성·수정은 날짜별 연결 일정 선택기를 각각 구현하며, 생성 쪽에는 조회 정책과 오류 표시가 있고 수정 쪽은 해당 query의 data 위주로 사용한다.

일정·경비 목록에도 날짜 범위 생성과 메뉴 상태 관리가 반복된다. 목록 화면 자체의 조회 오류 분기는 제한적이다. 공용 Input이 있어도 일부 입력은 원시 TextInput의 스타일을 반복한다.

의도적으로 다른 UX와 구현 과정에서 생긴 차이를 구분해야 한다. 모든 폼이나 화면을 하나로 합쳐야 한다는 결론은 아니다.

근거: [경비 생성 입력](../../../../../../apps/client/src/features/expense/create-expense/ExpenseForm.tsx) 31·239행, [경비 수정](../../../../../../apps/client/src/features/expense/update-expense/UpdateExpenseDrawer.tsx) 55·128행, [일정 목록](../../../../../../apps/client/src/screens/ScheduleScreen.tsx) 58·77행, [경비 목록](../../../../../../apps/client/src/screens/ExpensesScreen.tsx) 33·48행.
