"""Harness self-validation boundary."""
