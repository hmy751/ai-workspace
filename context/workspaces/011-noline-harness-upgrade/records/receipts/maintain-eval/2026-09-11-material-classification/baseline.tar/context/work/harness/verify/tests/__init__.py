"""Verify responsibility tests."""
